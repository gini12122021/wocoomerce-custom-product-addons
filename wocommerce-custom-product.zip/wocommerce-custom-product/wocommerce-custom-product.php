<?php
/**
 * Plugin Name:  WooCommerce Custom Product 
 * Description: Custom Product synchronization for WooCommerce.
 * Author: fen
 * Version: 1.0.0
 */

if ( ! class_exists( 'wcsfen' ) ) {
	include_once dirname( __FILE__ ) . '/includes/class-wcsfen.php';
}

