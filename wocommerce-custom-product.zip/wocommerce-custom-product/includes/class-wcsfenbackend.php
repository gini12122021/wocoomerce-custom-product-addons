<?php
	class wcsfenBackend extends wcsfen {
		
		public function __construct(){
			
		}

		
		
	}